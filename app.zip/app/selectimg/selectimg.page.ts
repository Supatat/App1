import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selectimg',
  templateUrl: './selectimg.page.html',
  styleUrls: ['./selectimg.page.scss'],
})
export class SelectimgPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
