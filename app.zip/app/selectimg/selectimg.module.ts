import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SelectimgPageRoutingModule } from './selectimg-routing.module';

import { SelectimgPage } from './selectimg.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SelectimgPageRoutingModule
  ],
  declarations: [SelectimgPage]
})
export class SelectimgPageModule {}
