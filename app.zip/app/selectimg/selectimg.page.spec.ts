import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SelectimgPage } from './selectimg.page';

describe('SelectimgPage', () => {
  let component: SelectimgPage;
  let fixture: ComponentFixture<SelectimgPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectimgPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SelectimgPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
